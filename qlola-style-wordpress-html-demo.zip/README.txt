TEMPLATE WORDPRESS / HTML DEMO
===============================

File index.html adalah template statis yang meniru struktur visual gambar:
- Header
- Hero/banner biru
- Logo teks demo
- Kartu login
- Registrasi Online
- Dua kartu layanan
- Footer responsif

Cara pakai di WordPress:
1. Buka editor halaman WordPress.
2. Pilih blok "HTML Khusus".
3. Salin isi <body> dari index.html, lalu masukkan CSS dari <style> ke CSS tambahan tema.
   ATAU gunakan plugin HTML/landing-page yang mengizinkan HTML lengkap.
4. Ubah teks dan CSS sesuai kebutuhan.

Catatan:
Form login dinonaktifkan dan tidak memiliki endpoint penyimpanan. Template tidak boleh digunakan untuk mengumpulkan kredensial perbankan.
